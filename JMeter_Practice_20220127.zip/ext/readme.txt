This directory hosts binary archives of Apache JMeter.

It can also be used for 3rd party JMeter plugins.
